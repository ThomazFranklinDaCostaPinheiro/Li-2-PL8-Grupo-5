var searchData=
[
  ['jogada_85',['JOGADA',['../struct_j_o_g_a_d_a.html',1,'']]]
];
