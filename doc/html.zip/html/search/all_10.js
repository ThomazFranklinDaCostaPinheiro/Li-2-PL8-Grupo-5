var searchData=
[
  ['ultima_5fjogada_77',['ultima_jogada',['../struct_e_s_t_a_d_o.html#a88f042640b66b99525b1c9d830893177',1,'ESTADO']]],
  ['um_78',['UM',['../_dados_8h.html#aba91601f16d4c485b2d9b8c429f27039ab620e38b0268bee43c7e9a88bd6e73fa',1,'Dados.h']]]
];
