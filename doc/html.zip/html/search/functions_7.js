var searchData=
[
  ['lerfich_124',['lerfich',['../_interface_8c.html#a13a5fd1ffeb05c1f7390581eb2ee7a05',1,'lerfich(char filename[], ESTADO *estado):&#160;Interface.c'],['../_interface_8h.html#a13a5fd1ffeb05c1f7390581eb2ee7a05',1,'lerfich(char filename[], ESTADO *estado):&#160;Interface.c']]],
  ['lista_5festa_5fvazia_125',['lista_esta_vazia',['../_listas_8c.html#a4c10928f7acaa4e3de3760cea0dfd9c0',1,'lista_esta_vazia(LISTA L):&#160;Listas.c'],['../_listas_8h.html#a4c10928f7acaa4e3de3760cea0dfd9c0',1,'lista_esta_vazia(LISTA L):&#160;Listas.c']]]
];
