var searchData=
[
  ['main_126',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['mostrar_5ftabuleiro_127',['mostrar_tabuleiro',['../_interface_8c.html#a4525a57d0cd9ed3c9150e19b67e1dad6',1,'mostrar_tabuleiro(ESTADO *estado):&#160;Interface.c'],['../_interface_8h.html#a4525a57d0cd9ed3c9150e19b67e1dad6',1,'mostrar_tabuleiro(ESTADO *estado):&#160;Interface.c']]],
  ['movs_128',['movs',['../_interface_8c.html#a9cd898393288bc7dfdb1fc9d76457ab7',1,'movs(ESTADO *e):&#160;Interface.c'],['../_interface_8h.html#a9cd898393288bc7dfdb1fc9d76457ab7',1,'movs(ESTADO *e):&#160;Interface.c']]]
];
