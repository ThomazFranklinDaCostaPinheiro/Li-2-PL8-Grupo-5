var searchData=
[
  ['linha_153',['linha',['../struct_c_o_o_r_d_e_n_a_d_a.html#af20d02e678ba0aeaf8727d747151baf0',1,'COORDENADA']]]
];
