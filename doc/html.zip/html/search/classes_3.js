var searchData=
[
  ['nodo_86',['nodo',['../structnodo.html',1,'']]]
];
