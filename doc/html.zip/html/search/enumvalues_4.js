var searchData=
[
  ['vazio_167',['VAZIO',['../_dados_8h.html#aba91601f16d4c485b2d9b8c429f27039abc711f491a56ec7af7a688be508c5113',1,'Dados.h']]]
];
