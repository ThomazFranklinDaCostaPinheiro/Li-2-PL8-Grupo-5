var searchData=
[
  ['qualcasa_71',['qualcasa',['../_logica_8c.html#a907bfeffe2704d04fad9c185bac094b3',1,'qualcasa(char c):&#160;Logica.c'],['../_logica_8h.html#a907bfeffe2704d04fad9c185bac094b3',1,'qualcasa(char c):&#160;Logica.c']]],
  ['quem_5fganha_72',['quem_ganha',['../_logica_8c.html#a703fcaaa11665ec5eb0ff2a3dc60a420',1,'quem_ganha(ESTADO *estado):&#160;Logica.c'],['../_logica_8h.html#a703fcaaa11665ec5eb0ff2a3dc60a420',1,'quem_ganha(ESTADO *estado):&#160;Logica.c']]]
];
