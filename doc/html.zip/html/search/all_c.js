var searchData=
[
  ['pos_68',['pos',['../_logica_8c.html#a0de576437e8b6e3c224a112334f018f1',1,'pos(ESTADO *e, int i):&#160;Logica.c'],['../_logica_8h.html#a0de576437e8b6e3c224a112334f018f1',1,'pos(ESTADO *e, int i):&#160;Logica.c']]],
  ['preta_69',['PRETA',['../_dados_8h.html#aba91601f16d4c485b2d9b8c429f27039a007278eb3827d19891b47cdd3ac8846d',1,'Dados.h']]],
  ['proximo_70',['proximo',['../structnodo.html#a03f1eceb28ca4022ecc73589b6ca39d9',1,'nodo::proximo()'],['../_listas_8c.html#ad9380152361127432c55c1c6067e05ae',1,'proximo(LISTA L):&#160;Listas.c'],['../_listas_8h.html#ad9380152361127432c55c1c6067e05ae',1,'proximo(LISTA L):&#160;Listas.c']]]
];
