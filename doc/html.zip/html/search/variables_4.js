var searchData=
[
  ['proximo_155',['proximo',['../structnodo.html#a03f1eceb28ca4022ecc73589b6ca39d9',1,'nodo']]]
];
