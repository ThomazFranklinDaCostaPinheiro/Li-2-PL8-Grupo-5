var searchData=
[
  ['alteracasa_0',['alteracasa',['../_dados_8c.html#a4bf4d4f1ccce3b17ef05423cd366b9e0',1,'alteracasa(ESTADO *e, int x, int y, CASA c):&#160;Dados.c'],['../_dados_8h.html#a4bf4d4f1ccce3b17ef05423cd366b9e0',1,'alteracasa(ESTADO *e, int x, int y, CASA c):&#160;Dados.c']]]
];
