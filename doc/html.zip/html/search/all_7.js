var searchData=
[
  ['jogada_36',['JOGADA',['../struct_j_o_g_a_d_a.html',1,'']]],
  ['jogadas_37',['jogadas',['../struct_e_s_t_a_d_o.html#a0e44ff9e999c7573f4b87cb8a7aba6c2',1,'ESTADO::jogadas()'],['../_dados_8h.html#a94c221d29a1760f008b7834093259b7d',1,'JOGADAS():&#160;Dados.h']]],
  ['jogador1_38',['jogador1',['../struct_j_o_g_a_d_a.html#aad7d21d5a8e288caf7e90f717066aa09',1,'JOGADA']]],
  ['jogador2_39',['jogador2',['../struct_j_o_g_a_d_a.html#a3dc122c89c610e66c84c57e574e2fdc0',1,'JOGADA']]],
  ['jogador_5fatual_40',['jogador_atual',['../struct_e_s_t_a_d_o.html#a6f3701db06762a60333719d94aa4d28c',1,'ESTADO']]],
  ['jogar_41',['jogar',['../_logica_8c.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;Logica.c'],['../_logica_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;Logica.c']]],
  ['jogs_42',['jogs',['../_logica_8c.html#a39a83bbb6b186655ccf97b767db14278',1,'jogs(ESTADO *e):&#160;Logica.c'],['../_logica_8h.html#a39a83bbb6b186655ccf97b767db14278',1,'jogs(ESTADO *e):&#160;Logica.c']]],
  ['jogs2_43',['jogs2',['../_logica_8c.html#a9265b7919a412964be25c72de9b526ab',1,'jogs2(ESTADO *e):&#160;Logica.c'],['../_logica_8h.html#a9265b7919a412964be25c72de9b526ab',1,'jogs2(ESTADO *e):&#160;Logica.c']]]
];
