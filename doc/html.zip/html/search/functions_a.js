var searchData=
[
  ['pos_139',['pos',['../_logica_8c.html#a0de576437e8b6e3c224a112334f018f1',1,'pos(ESTADO *e, int i):&#160;Logica.c'],['../_logica_8h.html#a0de576437e8b6e3c224a112334f018f1',1,'pos(ESTADO *e, int i):&#160;Logica.c']]],
  ['proximo_140',['proximo',['../_listas_8c.html#ad9380152361127432c55c1c6067e05ae',1,'proximo(LISTA L):&#160;Listas.c'],['../_listas_8h.html#ad9380152361127432c55c1c6067e05ae',1,'proximo(LISTA L):&#160;Listas.c']]]
];
