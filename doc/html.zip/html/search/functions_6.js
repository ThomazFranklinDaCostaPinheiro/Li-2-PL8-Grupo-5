var searchData=
[
  ['jogar_121',['jogar',['../_logica_8c.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;Logica.c'],['../_logica_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;Logica.c']]],
  ['jogs_122',['jogs',['../_logica_8c.html#a39a83bbb6b186655ccf97b767db14278',1,'jogs(ESTADO *e):&#160;Logica.c'],['../_logica_8h.html#a39a83bbb6b186655ccf97b767db14278',1,'jogs(ESTADO *e):&#160;Logica.c']]],
  ['jogs2_123',['jogs2',['../_logica_8c.html#a9265b7919a412964be25c72de9b526ab',1,'jogs2(ESTADO *e):&#160;Logica.c'],['../_logica_8h.html#a9265b7919a412964be25c72de9b526ab',1,'jogs2(ESTADO *e):&#160;Logica.c']]]
];
