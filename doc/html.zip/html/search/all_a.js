var searchData=
[
  ['nodo_56',['nodo',['../structnodo.html',1,'nodo'],['../_listas_8h.html#ab352ead3fb06267f3afdd032d67c189c',1,'NODO():&#160;Listas.h']]],
  ['num_5fjogadas_57',['num_jogadas',['../struct_e_s_t_a_d_o.html#a06af1e846368d0fc9525e78f4d86faa3',1,'ESTADO']]]
];
