var searchData=
[
  ['write_5fcoord_147',['write_coord',['../_interface_8c.html#abe85a0d9f8b389b7747666bb2e39dbf8',1,'write_coord(COORDENADA coord):&#160;Interface.c'],['../_interface_8h.html#abe85a0d9f8b389b7747666bb2e39dbf8',1,'write_coord(COORDENADA coord):&#160;Interface.c']]]
];
