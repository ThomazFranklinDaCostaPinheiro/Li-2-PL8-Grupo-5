var searchData=
[
  ['lerfich_44',['lerfich',['../_interface_8c.html#a13a5fd1ffeb05c1f7390581eb2ee7a05',1,'lerfich(char filename[], ESTADO *estado):&#160;Interface.c'],['../_interface_8h.html#a13a5fd1ffeb05c1f7390581eb2ee7a05',1,'lerfich(char filename[], ESTADO *estado):&#160;Interface.c']]],
  ['linha_45',['linha',['../struct_c_o_o_r_d_e_n_a_d_a.html#af20d02e678ba0aeaf8727d747151baf0',1,'COORDENADA']]],
  ['lista_46',['LISTA',['../_listas_8h.html#a2ed03b19209dd10718380b31b09a69f5',1,'Listas.h']]],
  ['lista_5festa_5fvazia_47',['lista_esta_vazia',['../_listas_8c.html#a4c10928f7acaa4e3de3760cea0dfd9c0',1,'lista_esta_vazia(LISTA L):&#160;Listas.c'],['../_listas_8h.html#a4c10928f7acaa4e3de3760cea0dfd9c0',1,'lista_esta_vazia(LISTA L):&#160;Listas.c']]],
  ['listas_2ec_48',['Listas.c',['../_listas_8c.html',1,'']]],
  ['listas_2eh_49',['Listas.h',['../_listas_8h.html',1,'']]],
  ['logica_2ec_50',['Logica.c',['../_logica_8c.html',1,'']]],
  ['logica_2eh_51',['Logica.h',['../_logica_8h.html',1,'']]]
];
