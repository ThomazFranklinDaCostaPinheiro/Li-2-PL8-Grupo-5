var searchData=
[
  ['desenha_5fjogada_103',['desenha_jogada',['../_logica_8c.html#a68e94a3c0d51af8099f17908ed15cfa8',1,'desenha_jogada(ESTADO *e, JOGADA jogada):&#160;Logica.c'],['../_logica_8h.html#a68e94a3c0d51af8099f17908ed15cfa8',1,'desenha_jogada(ESTADO *e, JOGADA jogada):&#160;Logica.c']]],
  ['devolve_5fcabeca_104',['devolve_cabeca',['../_listas_8c.html#abfcb205f3eb670157be0d1221021714b',1,'devolve_cabeca(LISTA L):&#160;Listas.c'],['../_listas_8h.html#abfcb205f3eb670157be0d1221021714b',1,'devolve_cabeca(LISTA L):&#160;Listas.c']]],
  ['distancia_105',['distancia',['../_logica_8c.html#a2b49bc3be4951d6204937cc3a5b4e9c2',1,'distancia(COORDENADA c1, COORDENADA c2):&#160;Logica.c'],['../_logica_8h.html#a2b49bc3be4951d6204937cc3a5b4e9c2',1,'distancia(COORDENADA c1, COORDENADA c2):&#160;Logica.c']]]
];
