var searchData=
[
  ['e_5fpeca_106',['e_peca',['../_logica_8c.html#aa8a94d8d4817ff867bd6ba658c9fc9ba',1,'e_peca(COORDENADA c):&#160;Logica.c'],['../_logica_8h.html#aa8a94d8d4817ff867bd6ba658c9fc9ba',1,'e_peca(COORDENADA c):&#160;Logica.c']]],
  ['e_5fvazio_107',['e_vazio',['../_logica_8c.html#a64ca232dda323890b0b9df79370b79ed',1,'e_vazio(COORDENADA c3, ESTADO *state):&#160;Logica.c'],['../_logica_8h.html#a64ca232dda323890b0b9df79370b79ed',1,'e_vazio(COORDENADA c3, ESTADO *state):&#160;Logica.c']]],
  ['e_5fvizinho_108',['e_vizinho',['../_logica_8c.html#aa0ac5baf8b7b832c7d55e5b2c55e0039',1,'e_vizinho(COORDENADA c1, COORDENADA c2):&#160;Logica.c'],['../_logica_8h.html#aa0ac5baf8b7b832c7d55e5b2c55e0039',1,'e_vizinho(COORDENADA c1, COORDENADA c2):&#160;Logica.c']]],
  ['encurralado_109',['encurralado',['../_logica_8c.html#a4eec13ff564158fa4077e44263639e95',1,'encurralado(ESTADO *estado):&#160;Logica.c'],['../_logica_8h.html#a4eec13ff564158fa4077e44263639e95',1,'encurralado(ESTADO *estado):&#160;Logica.c']]],
  ['erros_110',['erros',['../_interface_8c.html#aa12c29340c66dea6b85486aafce73e58',1,'erros(int n):&#160;Interface.c'],['../_interface_8h.html#aa12c29340c66dea6b85486aafce73e58',1,'erros(int n):&#160;Interface.c']]],
  ['euclidiana_111',['euclidiana',['../_logica_8c.html#a8e0d5c76435c7186eb9081daf60e118f',1,'euclidiana(LISTA l, int player):&#160;Logica.c'],['../_logica_8h.html#a8e0d5c76435c7186eb9081daf60e118f',1,'euclidiana(LISTA l, int player):&#160;Logica.c']]]
];
