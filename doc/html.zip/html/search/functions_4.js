var searchData=
[
  ['gravar_112',['gravar',['../_interface_8c.html#abbd876b144cd2b43aa5f6ad551eb480b',1,'gravar(ESTADO *estado, char filename[]):&#160;Interface.c'],['../_interface_8h.html#abbd876b144cd2b43aa5f6ad551eb480b',1,'gravar(ESTADO *estado, char filename[]):&#160;Interface.c']]],
  ['guarda_5fjogada_113',['guarda_jogada',['../_dados_8c.html#a09b3a38b3ae012990530ac8107d80569',1,'guarda_jogada(ESTADO *e, int j, int nj, int y, int x):&#160;Dados.c'],['../_dados_8h.html#a09b3a38b3ae012990530ac8107d80569',1,'guarda_jogada(ESTADO *e, int j, int nj, int y, int x):&#160;Dados.c']]],
  ['guarda_5fjogada_5fcoord_114',['guarda_jogada_coord',['../_dados_8c.html#aa5477de13b00cc1d1950d8314c268de6',1,'guarda_jogada_coord(ESTADO *e, int j, int nj, COORDENADA c):&#160;Dados.c'],['../_dados_8h.html#aa5477de13b00cc1d1950d8314c268de6',1,'guarda_jogada_coord(ESTADO *e, int j, int nj, COORDENADA c):&#160;Dados.c']]],
  ['guarda_5fnum_5fjogs_115',['guarda_num_jogs',['../_dados_8c.html#a616a1f3045d63dda6820e06ab87b42ce',1,'guarda_num_jogs(ESTADO *e, int n):&#160;Dados.c'],['../_dados_8h.html#a616a1f3045d63dda6820e06ab87b42ce',1,'guarda_num_jogs(ESTADO *e, int n):&#160;Dados.c']]],
  ['guarda_5fultima_5fjog_116',['guarda_ultima_jog',['../_dados_8c.html#a0cecf912ae5bddea7a59d684c7cfe1ba',1,'guarda_ultima_jog(ESTADO *e, int y, int x):&#160;Dados.c'],['../_dados_8h.html#a0cecf912ae5bddea7a59d684c7cfe1ba',1,'guarda_ultima_jog(ESTADO *e, int y, int x):&#160;Dados.c']]],
  ['guardar_5fjogador_117',['guardar_jogador',['../_dados_8c.html#ae7bce55ca6469ed653b6b668d652504d',1,'guardar_jogador(ESTADO *e, int n):&#160;Dados.c'],['../_dados_8h.html#ae7bce55ca6469ed653b6b668d652504d',1,'guardar_jogador(ESTADO *e, int n):&#160;Dados.c']]]
];
