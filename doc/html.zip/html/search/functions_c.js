var searchData=
[
  ['rand_5fcoord_143',['rand_coord',['../_logica_8c.html#a60a8eb9cbfb8d50716674ce3be1bc397',1,'rand_coord(LISTA l):&#160;Logica.c'],['../_logica_8h.html#a60a8eb9cbfb8d50716674ce3be1bc397',1,'rand_coord(LISTA l):&#160;Logica.c']]],
  ['remove_5fcabeca_144',['remove_cabeca',['../_listas_8c.html#a9026a681a68322b5ec7f07137b864cbd',1,'remove_cabeca(LISTA L):&#160;Listas.c'],['../_listas_8h.html#a9026a681a68322b5ec7f07137b864cbd',1,'remove_cabeca(LISTA L):&#160;Listas.c']]],
  ['reset_5ftab_145',['reset_tab',['../_logica_8c.html#a1598427912dd475a62c8510b9954e850',1,'reset_tab(ESTADO *e):&#160;Logica.c'],['../_logica_8h.html#a1598427912dd475a62c8510b9954e850',1,'reset_tab(ESTADO *e):&#160;Logica.c']]]
];
