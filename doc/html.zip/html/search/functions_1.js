var searchData=
[
  ['casas_5fdisp_98',['casas_disp',['../_logica_8c.html#a4ed31b0ec6bb43c061b5decef4e2bf9e',1,'casas_disp(ESTADO *e, COORDENADA c):&#160;Logica.c'],['../_logica_8h.html#a4ed31b0ec6bb43c061b5decef4e2bf9e',1,'casas_disp(ESTADO *e, COORDENADA c):&#160;Logica.c']]],
  ['char_5fint_99',['char_int',['../_interface_8c.html#abc79096c61e8f7124d188824b2ecec7d',1,'char_int(char c):&#160;Interface.c'],['../_interface_8h.html#abc79096c61e8f7124d188824b2ecec7d',1,'char_int(char c):&#160;Interface.c']]],
  ['conv_5fc_100',['conv_c',['../_dados_8c.html#a9f0dd79778fc7f41098b93a1e29bdcb9',1,'conv_c(int col):&#160;Dados.c'],['../_dados_8h.html#a9f0dd79778fc7f41098b93a1e29bdcb9',1,'conv_c(int col):&#160;Dados.c']]],
  ['conv_5fl_101',['conv_l',['../_dados_8c.html#acb70dbd3905a451c8d815addb17b9c3a',1,'conv_l(int lin):&#160;Dados.c'],['../_dados_8h.html#acb70dbd3905a451c8d815addb17b9c3a',1,'conv_l(int lin):&#160;Dados.c']]],
  ['criar_5flista_102',['criar_lista',['../_listas_8c.html#ae3b99323b6f8f35d80bb69ff1a27985e',1,'criar_lista():&#160;Listas.c'],['../_listas_8h.html#ae3b99323b6f8f35d80bb69ff1a27985e',1,'criar_lista():&#160;Listas.c']]]
];
