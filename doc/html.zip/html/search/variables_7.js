var searchData=
[
  ['valor_158',['valor',['../structnodo.html#ac78f1a082a695595f0d3ed32cead97f4',1,'nodo']]]
];
