var searchData=
[
  ['vencer_146',['vencer',['../_logica_8c.html#a819b689cf358a197b747e52b27ad30f2',1,'vencer(ESTADO *estado):&#160;Logica.c'],['../_logica_8h.html#a819b689cf358a197b747e52b27ad30f2',1,'vencer(ESTADO *estado):&#160;Logica.c']]]
];
