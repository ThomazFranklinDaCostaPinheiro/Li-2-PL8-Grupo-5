var searchData=
[
  ['dados_2ec_10',['Dados.c',['../_dados_8c.html',1,'']]],
  ['dados_2eh_11',['Dados.h',['../_dados_8h.html',1,'']]],
  ['desenha_5fjogada_12',['desenha_jogada',['../_l_xC3_xB3gica_8c.html#a68e94a3c0d51af8099f17908ed15cfa8',1,'desenha_jogada(ESTADO *e, JOGADA jogada):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#a68e94a3c0d51af8099f17908ed15cfa8',1,'desenha_jogada(ESTADO *e, JOGADA jogada):&#160;Lógica.c']]],
  ['dois_13',['DOIS',['../_dados_8h.html#aba91601f16d4c485b2d9b8c429f27039a2bf153109d0c8b96e61bc18d5be7c5da',1,'Dados.h']]]
];
