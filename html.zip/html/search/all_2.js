var searchData=
[
  ['casa_3',['CASA',['../_dados_8h.html#aba91601f16d4c485b2d9b8c429f27039',1,'Dados.h']]],
  ['cmakelists_2etxt_4',['CMakeLists.txt',['../_c_make_lists_8txt.html',1,'']]],
  ['coluna_5',['coluna',['../struct_c_o_o_r_d_e_n_a_d_a.html#a4a2f44649af1dfbf8d13141d5a336455',1,'COORDENADA']]],
  ['conv_5fc_6',['conv_c',['../_l_xC3_xB3gica_8c.html#a9f0dd79778fc7f41098b93a1e29bdcb9',1,'conv_c(int col):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#a9f0dd79778fc7f41098b93a1e29bdcb9',1,'conv_c(int col):&#160;Lógica.c']]],
  ['conv_5fl_7',['conv_l',['../_l_xC3_xB3gica_8c.html#acb70dbd3905a451c8d815addb17b9c3a',1,'conv_l(int lin):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#acb70dbd3905a451c8d815addb17b9c3a',1,'conv_l(int lin):&#160;Lógica.c']]],
  ['conversor_8',['conversor',['../_interface_8h.html#a304611be3063e2540503f4f7c8c2ec39',1,'Interface.h']]],
  ['coordenada_9',['COORDENADA',['../struct_c_o_o_r_d_e_n_a_d_a.html',1,'']]]
];
