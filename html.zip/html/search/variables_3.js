var searchData=
[
  ['num_5fjogadas_100',['num_jogadas',['../struct_e_s_t_a_d_o.html#a06af1e846368d0fc9525e78f4d86faa3',1,'ESTADO']]]
];
