var searchData=
[
  ['inicializar_5festado_22',['inicializar_estado',['../_dados_8c.html#a7e0c7e26fb685d9ab501e19b05e6954f',1,'inicializar_estado():&#160;Dados.c'],['../_dados_8h.html#a7e0c7e26fb685d9ab501e19b05e6954f',1,'inicializar_estado():&#160;Dados.c']]],
  ['interface_2ec_23',['Interface.c',['../_interface_8c.html',1,'']]],
  ['interface_2eh_24',['Interface.h',['../_interface_8h.html',1,'']]],
  ['interpretador_25',['interpretador',['../_interface_8c.html#a24da95ebeede4a540e37790ce8be359b',1,'interpretador(ESTADO *e):&#160;Interface.c'],['../_interface_8h.html#a24da95ebeede4a540e37790ce8be359b',1,'interpretador(ESTADO *e):&#160;Interface.c']]]
];
