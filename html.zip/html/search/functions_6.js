var searchData=
[
  ['jogar_80',['jogar',['../_l_xC3_xB3gica_8c.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;Lógica.c']]]
];
