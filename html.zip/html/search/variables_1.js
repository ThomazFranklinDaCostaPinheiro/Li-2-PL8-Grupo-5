var searchData=
[
  ['jogadas_71',['jogadas',['../struct_e_s_t_a_d_o.html#a0e44ff9e999c7573f4b87cb8a7aba6c2',1,'ESTADO']]],
  ['jogador1_72',['jogador1',['../struct_j_o_g_a_d_a.html#aad7d21d5a8e288caf7e90f717066aa09',1,'JOGADA']]],
  ['jogador2_73',['jogador2',['../struct_j_o_g_a_d_a.html#a3dc122c89c610e66c84c57e574e2fdc0',1,'JOGADA']]],
  ['jogador_5fatual_74',['jogador_atual',['../struct_e_s_t_a_d_o.html#a6f3701db06762a60333719d94aa4d28c',1,'ESTADO']]]
];
