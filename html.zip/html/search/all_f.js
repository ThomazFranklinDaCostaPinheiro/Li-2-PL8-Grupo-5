var searchData=
[
  ['vazio_41',['VAZIO',['../_dados_8h.html#aba91601f16d4c485b2d9b8c429f27039abc711f491a56ec7af7a688be508c5113',1,'Dados.h']]],
  ['vencer_42',['vencer',['../_interface_8c.html#a819b689cf358a197b747e52b27ad30f2',1,'Interface.c']]]
];
