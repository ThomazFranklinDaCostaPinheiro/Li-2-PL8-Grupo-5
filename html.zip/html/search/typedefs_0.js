var searchData=
[
  ['jogadas_103',['JOGADAS',['../_dados_8h.html#a94c221d29a1760f008b7834093259b7d',1,'Dados.h']]]
];
