var searchData=
[
  ['casa_2',['CASA',['../_dados_8h.html#aba91601f16d4c485b2d9b8c429f27039',1,'Dados.h']]],
  ['cmakelists_2etxt_3',['CMakeLists.txt',['../_c_make_lists_8txt.html',1,'']]],
  ['coluna_4',['coluna',['../struct_c_o_o_r_d_e_n_a_d_a.html#a4a2f44649af1dfbf8d13141d5a336455',1,'COORDENADA']]],
  ['coordenada_5',['COORDENADA',['../struct_c_o_o_r_d_e_n_a_d_a.html',1,'']]]
];
