var searchData=
[
  ['vencer_92',['vencer',['../_interface_8c.html#a819b689cf358a197b747e52b27ad30f2',1,'vencer(ESTADO *estado):&#160;Interface.c'],['../_interface_8h.html#a819b689cf358a197b747e52b27ad30f2',1,'vencer(ESTADO *estado):&#160;Interface.c']]]
];
