var searchData=
[
  ['main_63',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['mostrar_5ftabuleiro_64',['mostrar_tabuleiro',['../_interface_8c.html#a4525a57d0cd9ed3c9150e19b67e1dad6',1,'Interface.c']]]
];
