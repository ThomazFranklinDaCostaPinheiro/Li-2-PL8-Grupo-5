var searchData=
[
  ['desenha_5fjogada_70',['desenha_jogada',['../_l_xC3_xB3gica_8c.html#a68e94a3c0d51af8099f17908ed15cfa8',1,'desenha_jogada(ESTADO *e, JOGADA jogada):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#a68e94a3c0d51af8099f17908ed15cfa8',1,'desenha_jogada(ESTADO *e, JOGADA jogada):&#160;Lógica.c']]]
];
