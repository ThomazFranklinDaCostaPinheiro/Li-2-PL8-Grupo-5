var searchData=
[
  ['branca_0',['BRANCA',['../_dados_8h.html#aba91601f16d4c485b2d9b8c429f27039ad24485fddec75419fd4a0cc9edda0ca5',1,'Dados.h']]],
  ['buf_5fsize_1',['BUF_SIZE',['../_interface_8c.html#a6821bafc3c88dfb2e433a095df9940c6',1,'Interface.c']]]
];
