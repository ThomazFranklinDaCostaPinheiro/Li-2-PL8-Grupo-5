var searchData=
[
  ['armazenar_0',['armazenar',['../_interface_8h.html#af7e0976d604fffe441fb8dcad3f2fcb3',1,'Interface.h']]]
];
