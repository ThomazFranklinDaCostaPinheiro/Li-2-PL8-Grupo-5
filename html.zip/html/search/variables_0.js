var searchData=
[
  ['coluna_70',['coluna',['../struct_c_o_o_r_d_e_n_a_d_a.html#a4a2f44649af1dfbf8d13141d5a336455',1,'COORDENADA']]]
];
