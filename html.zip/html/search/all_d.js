var searchData=
[
  ['tab_38',['tab',['../struct_e_s_t_a_d_o.html#a00c6ffee9c6e637d4178cb6e8846a578',1,'ESTADO']]]
];
