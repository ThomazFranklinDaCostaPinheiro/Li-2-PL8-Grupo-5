var searchData=
[
  ['qualcasa_46',['qualcasa',['../_interface_8c.html#a907bfeffe2704d04fad9c185bac094b3',1,'Interface.c']]],
  ['quem_5fganha_47',['quem_ganha',['../_interface_8c.html#a703fcaaa11665ec5eb0ff2a3dc60a420',1,'quem_ganha(ESTADO *estado):&#160;Interface.c'],['../_interface_8h.html#a703fcaaa11665ec5eb0ff2a3dc60a420',1,'quem_ganha(ESTADO *estado):&#160;Interface.c']]]
];
