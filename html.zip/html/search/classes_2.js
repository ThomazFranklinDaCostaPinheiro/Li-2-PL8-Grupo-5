var searchData=
[
  ['jogada_57',['JOGADA',['../struct_j_o_g_a_d_a.html',1,'']]]
];
