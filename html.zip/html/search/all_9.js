var searchData=
[
  ['main_36',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['main_2ec_37',['main.c',['../main_8c.html',1,'']]],
  ['mostrar_5ftabuleiro_38',['mostrar_tabuleiro',['../_interface_8c.html#a4525a57d0cd9ed3c9150e19b67e1dad6',1,'mostrar_tabuleiro(ESTADO *estado):&#160;Interface.c'],['../_interface_8h.html#a4525a57d0cd9ed3c9150e19b67e1dad6',1,'mostrar_tabuleiro(ESTADO *estado):&#160;Interface.c']]],
  ['movs_39',['movs',['../_l_xC3_xB3gica_8c.html#a9cd898393288bc7dfdb1fc9d76457ab7',1,'movs(ESTADO *e):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#a9cd898393288bc7dfdb1fc9d76457ab7',1,'movs(ESTADO *e):&#160;Lógica.c']]]
];
