var searchData=
[
  ['lerfich_25',['lerfich',['../_interface_8c.html#a13a5fd1ffeb05c1f7390581eb2ee7a05',1,'Interface.c']]],
  ['linha_26',['linha',['../struct_c_o_o_r_d_e_n_a_d_a.html#af20d02e678ba0aeaf8727d747151baf0',1,'COORDENADA']]],
  ['logica_2ec_27',['Logica.c',['../_logica_8c.html',1,'']]],
  ['logica_2eh_28',['Logica.h',['../_logica_8h.html',1,'']]]
];
