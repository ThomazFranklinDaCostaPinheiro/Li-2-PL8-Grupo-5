var searchData=
[
  ['jogada_26',['JOGADA',['../struct_j_o_g_a_d_a.html',1,'']]],
  ['jogadas_27',['jogadas',['../struct_e_s_t_a_d_o.html#a0e44ff9e999c7573f4b87cb8a7aba6c2',1,'ESTADO::jogadas()'],['../_dados_8h.html#a94c221d29a1760f008b7834093259b7d',1,'JOGADAS():&#160;Dados.h']]],
  ['jogador1_28',['jogador1',['../struct_j_o_g_a_d_a.html#aad7d21d5a8e288caf7e90f717066aa09',1,'JOGADA']]],
  ['jogador2_29',['jogador2',['../struct_j_o_g_a_d_a.html#a3dc122c89c610e66c84c57e574e2fdc0',1,'JOGADA']]],
  ['jogador_5fatual_30',['jogador_atual',['../struct_e_s_t_a_d_o.html#a6f3701db06762a60333719d94aa4d28c',1,'ESTADO']]],
  ['jogar_31',['jogar',['../_l_xC3_xB3gica_8c.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;Lógica.c']]]
];
