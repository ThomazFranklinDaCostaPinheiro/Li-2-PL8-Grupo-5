var searchData=
[
  ['preta_36',['PRETA',['../_dados_8h.html#aba91601f16d4c485b2d9b8c429f27039a007278eb3827d19891b47cdd3ac8846d',1,'Dados.h']]]
];
