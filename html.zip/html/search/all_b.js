var searchData=
[
  ['obter_5festado_5fcasa_41',['obter_estado_casa',['../_dados_8c.html#a6faa68373203923729ed38657aa0f768',1,'obter_estado_casa(ESTADO *e, COORDENADA c):&#160;Dados.c'],['../_dados_8h.html#a6faa68373203923729ed38657aa0f768',1,'obter_estado_casa(ESTADO *e, COORDENADA c):&#160;Dados.c']]],
  ['obter_5fjogador_5fatual_42',['obter_jogador_atual',['../_dados_8c.html#ad6e326e4ffa57ca1ae0c75377ecefc8c',1,'obter_jogador_atual(ESTADO *estado):&#160;Dados.c'],['../_dados_8h.html#ad6e326e4ffa57ca1ae0c75377ecefc8c',1,'obter_jogador_atual(ESTADO *estado):&#160;Dados.c']]],
  ['obter_5fnumero_5fde_5fjogadas_43',['obter_numero_de_jogadas',['../_dados_8c.html#a6cd0b387bdee9e18003c78852394aa63',1,'obter_numero_de_jogadas(ESTADO *estado):&#160;Dados.c'],['../_dados_8h.html#a6cd0b387bdee9e18003c78852394aa63',1,'obter_numero_de_jogadas(ESTADO *estado):&#160;Dados.c']]]
];
