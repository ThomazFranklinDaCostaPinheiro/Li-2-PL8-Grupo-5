var indexSectionsWithContent =
{
  0: "abcdegijlmnopqrtuvw",
  1: "cej",
  2: "cdilm",
  3: "acdegijlmopqrvw",
  4: "cjlntu",
  5: "j",
  6: "c",
  7: "bdpuv",
  8: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Estruturas de dados",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de tipos",
  6: "Enumerações",
  7: "Valores de enumerações",
  8: "Macros"
};

