var searchData=
[
  ['vencer_69',['vencer',['../_interface_8c.html#a819b689cf358a197b747e52b27ad30f2',1,'Interface.c']]]
];
