var searchData=
[
  ['buf_5fsize_86',['BUF_SIZE',['../_interface_8c.html#a6821bafc3c88dfb2e433a095df9940c6',1,'Interface.c']]]
];
