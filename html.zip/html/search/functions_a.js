var searchData=
[
  ['pos_88',['pos',['../_l_xC3_xB3gica_8c.html#ad684707f2c98401f85ca361db6709d9d',1,'pos(ESTADO *e, int i):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#a7e44d662f84d307233643dd55409cb58',1,'pos(ESTADO *e, int i):&#160;Lógica.c']]]
];
