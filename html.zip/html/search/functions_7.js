var searchData=
[
  ['quem_5fganha_68',['quem_ganha',['../_interface_8c.html#a703fcaaa11665ec5eb0ff2a3dc60a420',1,'quem_ganha(ESTADO *estado):&#160;Interface.c'],['../_interface_8h.html#a703fcaaa11665ec5eb0ff2a3dc60a420',1,'quem_ganha(ESTADO *estado):&#160;Interface.c']]]
];
