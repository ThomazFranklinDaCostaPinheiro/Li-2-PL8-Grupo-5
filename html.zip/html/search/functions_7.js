var searchData=
[
  ['lerfich_81',['lerfich',['../_interface_8c.html#a13a5fd1ffeb05c1f7390581eb2ee7a05',1,'lerfich(char filename[], ESTADO *estado):&#160;Interface.c'],['../_interface_8h.html#a13a5fd1ffeb05c1f7390581eb2ee7a05',1,'lerfich(char filename[], ESTADO *estado):&#160;Interface.c']]]
];
