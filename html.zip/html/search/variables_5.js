var searchData=
[
  ['ultima_5fjogada_102',['ultima_jogada',['../struct_e_s_t_a_d_o.html#a88f042640b66b99525b1c9d830893177',1,'ESTADO']]]
];
