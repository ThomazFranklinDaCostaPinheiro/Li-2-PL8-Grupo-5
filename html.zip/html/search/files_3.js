var searchData=
[
  ['logica_2ec_51',['Logica.c',['../_logica_8c.html',1,'']]],
  ['logica_2eh_52',['Logica.h',['../_logica_8h.html',1,'']]]
];
