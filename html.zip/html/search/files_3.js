var searchData=
[
  ['lógica_2ec_63',['Lógica.c',['../_l_xC3_xB3gica_8c.html',1,'']]],
  ['lógica_2eh_64',['Lógica.h',['../_l_xC3_xB3gica_8h.html',1,'']]]
];
