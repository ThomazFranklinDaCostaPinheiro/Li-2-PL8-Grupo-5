var searchData=
[
  ['pos_44',['pos',['../_l_xC3_xB3gica_8c.html#ad684707f2c98401f85ca361db6709d9d',1,'pos(ESTADO *e, int i):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#a7e44d662f84d307233643dd55409cb58',1,'pos(ESTADO *e, int i):&#160;Lógica.c']]],
  ['preta_45',['PRETA',['../_dados_8h.html#aba91601f16d4c485b2d9b8c429f27039a007278eb3827d19891b47cdd3ac8846d',1,'Dados.h']]]
];
