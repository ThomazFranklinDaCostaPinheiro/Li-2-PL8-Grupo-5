var searchData=
[
  ['reset_5ftab_48',['reset_tab',['../_l_xC3_xB3gica_8c.html#a1598427912dd475a62c8510b9954e850',1,'reset_tab(ESTADO *e):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#a1598427912dd475a62c8510b9954e850',1,'reset_tab(ESTADO *e):&#160;Lógica.c']]]
];
