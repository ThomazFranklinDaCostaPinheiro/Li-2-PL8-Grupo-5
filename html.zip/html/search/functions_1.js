var searchData=
[
  ['conv_5fc_67',['conv_c',['../_l_xC3_xB3gica_8c.html#a9f0dd79778fc7f41098b93a1e29bdcb9',1,'conv_c(int col):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#a9f0dd79778fc7f41098b93a1e29bdcb9',1,'conv_c(int col):&#160;Lógica.c']]],
  ['conv_5fl_68',['conv_l',['../_l_xC3_xB3gica_8c.html#acb70dbd3905a451c8d815addb17b9c3a',1,'conv_l(int lin):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#acb70dbd3905a451c8d815addb17b9c3a',1,'conv_l(int lin):&#160;Lógica.c']]],
  ['conversor_69',['conversor',['../_interface_8h.html#a304611be3063e2540503f4f7c8c2ec39',1,'Interface.h']]]
];
