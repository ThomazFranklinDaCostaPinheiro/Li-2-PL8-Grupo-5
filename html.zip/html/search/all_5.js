var searchData=
[
  ['gravar_19',['gravar',['../_interface_8c.html#abbd876b144cd2b43aa5f6ad551eb480b',1,'gravar(ESTADO *estado, char filename[]):&#160;Interface.c'],['../_interface_8h.html#abbd876b144cd2b43aa5f6ad551eb480b',1,'gravar(ESTADO *estado, char filename[]):&#160;Interface.c']]],
  ['guardar_5fjogada1_20',['guardar_jogada1',['../_interface_8c.html#a0da7620d44d716748d442f2b1f4c60ae',1,'guardar_jogada1(ESTADO *e, int j, char cha, int l):&#160;Interface.c'],['../_interface_8h.html#a0da7620d44d716748d442f2b1f4c60ae',1,'guardar_jogada1(ESTADO *e, int j, char cha, int l):&#160;Interface.c']]],
  ['guardar_5fjogada2_21',['guardar_jogada2',['../_interface_8c.html#aa3586568d3993ea863a1d5fd737f2a0d',1,'guardar_jogada2(ESTADO *e, int j, char cha, int l):&#160;Interface.c'],['../_interface_8h.html#aa3586568d3993ea863a1d5fd737f2a0d',1,'guardar_jogada2(ESTADO *e, int j, char cha, int l):&#160;Interface.c']]]
];
