var searchData=
[
  ['main_29',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['main_2ec_30',['main.c',['../main_8c.html',1,'']]],
  ['mostrar_5ftabuleiro_31',['mostrar_tabuleiro',['../_interface_8c.html#a4525a57d0cd9ed3c9150e19b67e1dad6',1,'Interface.c']]]
];
