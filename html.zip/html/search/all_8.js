var searchData=
[
  ['lerfich_32',['lerfich',['../_interface_8c.html#a13a5fd1ffeb05c1f7390581eb2ee7a05',1,'lerfich(char filename[], ESTADO *estado):&#160;Interface.c'],['../_interface_8h.html#a13a5fd1ffeb05c1f7390581eb2ee7a05',1,'lerfich(char filename[], ESTADO *estado):&#160;Interface.c']]],
  ['linha_33',['linha',['../struct_c_o_o_r_d_e_n_a_d_a.html#af20d02e678ba0aeaf8727d747151baf0',1,'COORDENADA']]],
  ['lógica_2ec_34',['Lógica.c',['../_l_xC3_xB3gica_8c.html',1,'']]],
  ['lógica_2eh_35',['Lógica.h',['../_l_xC3_xB3gica_8h.html',1,'']]]
];
