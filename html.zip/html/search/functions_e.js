var searchData=
[
  ['write_5fcoord_93',['write_coord',['../_l_xC3_xB3gica_8c.html#abe85a0d9f8b389b7747666bb2e39dbf8',1,'write_coord(COORDENADA coord):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#abe85a0d9f8b389b7747666bb2e39dbf8',1,'write_coord(COORDENADA coord):&#160;Lógica.c']]]
];
