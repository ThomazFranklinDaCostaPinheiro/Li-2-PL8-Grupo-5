var searchData=
[
  ['jogar_61',['jogar',['../_logica_8c.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;Logica.c'],['../_logica_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;Logica.c']]]
];
