var searchData=
[
  ['gravar_14',['gravar',['../_interface_8c.html#abbd876b144cd2b43aa5f6ad551eb480b',1,'gravar(ESTADO *estado, char filename[]):&#160;Interface.c'],['../_interface_8h.html#abbd876b144cd2b43aa5f6ad551eb480b',1,'gravar(ESTADO *estado, char filename[]):&#160;Interface.c']]]
];
