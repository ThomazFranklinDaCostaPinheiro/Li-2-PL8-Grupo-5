var searchData=
[
  ['e_5fpeca_14',['e_peca',['../_l_xC3_xB3gica_8c.html#aa8a94d8d4817ff867bd6ba658c9fc9ba',1,'e_peca(COORDENADA c):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#aa8a94d8d4817ff867bd6ba658c9fc9ba',1,'e_peca(COORDENADA c):&#160;Lógica.c']]],
  ['e_5fvazio_15',['e_vazio',['../_l_xC3_xB3gica_8c.html#a64ca232dda323890b0b9df79370b79ed',1,'e_vazio(COORDENADA c3, ESTADO *state):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#a64ca232dda323890b0b9df79370b79ed',1,'e_vazio(COORDENADA c3, ESTADO *state):&#160;Lógica.c']]],
  ['e_5fvizinho_16',['e_vizinho',['../_l_xC3_xB3gica_8c.html#aa0ac5baf8b7b832c7d55e5b2c55e0039',1,'e_vizinho(COORDENADA c1, COORDENADA c2):&#160;Lógica.c'],['../_l_xC3_xB3gica_8h.html#aa0ac5baf8b7b832c7d55e5b2c55e0039',1,'e_vizinho(COORDENADA c1, COORDENADA c2):&#160;Lógica.c']]],
  ['encurralado_17',['encurralado',['../_interface_8c.html#a4eec13ff564158fa4077e44263639e95',1,'encurralado(ESTADO *estado):&#160;Interface.c'],['../_interface_8h.html#a4eec13ff564158fa4077e44263639e95',1,'encurralado(ESTADO *estado):&#160;Interface.c']]],
  ['estado_18',['ESTADO',['../struct_e_s_t_a_d_o.html',1,'']]]
];
